# Student Management System

A simple command-line **Student Management System** built with **Python** and **SQLite (SQL database)**.
It supports adding, viewing, updating, deleting, and searching student records.

## Features
- ➕ Add Student
- 📋 View All Students
- ✏️ Update Student
- 🗑️ Delete Student
- 🔍 Search Student (by name or roll number)
- 🗄️ Data stored permanently in a SQLite database (`students.db`)

## Tech Stack
- **Language:** Python 3
- **Database:** SQLite3 (built into Python, no installation needed)

## Project Structure
```
student-management-system/
│
├── main.py         # Entry point - run this file to start the app
├── crud.py         # Add / View / Update / Delete / Search functions
├── database.py     # Database connection and table creation
└── README.md        # Project documentation
```

> Note: `students.db` is created automatically the first time you run the program — you don't need to create it manually.

## How to Run

1. Make sure **Python 3** is installed on your system.
   Check with:
   ```
   python --version
   ```

2. Download/clone the project files into one folder, keeping all three
   `.py` files (`main.py`, `crud.py`, `database.py`) together in the same folder.

3. Open a terminal in that folder and run:
   ```
   python main.py
   ```

4. Follow the on-screen menu to add, view, update, delete, or search students.

No external libraries are required — everything used (`sqlite3`) comes built into Python.

## How to Upload to GitHub

1. Create a new repository on GitHub (or open your existing **Student Management System** repo).
2. On your computer, put `main.py`, `crud.py`, `database.py`, and `README.md`
   inside your local project folder (the same one that matches your repo).
3. Open a terminal in that folder and run:
   ```
   git init                     # only if the folder isn't a git repo yet
   git add main.py crud.py database.py README.md
   git commit -m "Add Student Management System source files"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo-name>.git
   git push -u origin main
   ```
   If the repo already exists and is already connected, you can skip
   `git init`, `git branch -M main`, and `git remote add origin` — just run:
   ```
   git add main.py crud.py database.py README.md
   git commit -m "Add source files"
   git push
   ```
4. Refresh your GitHub repository page — the files should now appear there.

**Tip:** Do not upload `students.db` to GitHub, since it's generated
locally each time someone runs the program. You can add a `.gitignore`
file with this line to keep it out of the repo:
```
students.db
```

## Example Usage
```
===== Student Management System =====
1. Add Student
2. View All Students
3. Update Student
4. Delete Student
5. Search Student
6. Exit
Enter your choice (1-6): 1
Enter name: Priya Sharma
Enter roll number: CSE101
Enter branch: CSE
Enter year: 2
Enter email: priya@example.com
✅ Student added successfully.
```

## Author
Built as a mini academic project for a B.Tech CSE student.
