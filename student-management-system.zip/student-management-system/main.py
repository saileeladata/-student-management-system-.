"""
main.py
Entry point for the Student Management System.
Run this file to start the application.
"""

from database import create_table
import crud


def print_menu():
    print("\n===== Student Management System =====")
    print("1. Add Student")
    print("2. View All Students")
    print("3. Update Student")
    print("4. Delete Student")
    print("5. Search Student")
    print("6. Exit")


def main():
    create_table()

    while True:
        print_menu()
        choice = input("Enter your choice (1-6): ").strip()

        if choice == "1":
            name = input("Enter name: ").strip()
            roll_no = input("Enter roll number: ").strip()
            branch = input("Enter branch: ").strip()
            year = input("Enter year: ").strip()
            email = input("Enter email: ").strip()
            crud.add_student(name, roll_no, branch, year, email)

        elif choice == "2":
            crud.view_students()

        elif choice == "3":
            roll_no = input("Enter roll number of student to update: ").strip()
            print("Leave a field blank to keep its current value.")
            name = input("New name: ").strip() or None
            branch = input("New branch: ").strip() or None
            year = input("New year: ").strip() or None
            email = input("New email: ").strip() or None
            crud.update_student(roll_no, name, branch, year, email)

        elif choice == "4":
            roll_no = input("Enter roll number of student to delete: ").strip()
            crud.delete_student(roll_no)

        elif choice == "5":
            keyword = input("Enter name or roll number to search: ").strip()
            crud.search_student(keyword)

        elif choice == "6":
            print("Exiting... Goodbye!")
            break

        else:
            print("❌ Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
