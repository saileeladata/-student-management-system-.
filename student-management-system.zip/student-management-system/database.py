"""
database.py
Handles the SQLite database connection and table creation
for the Student Management System.
"""

import sqlite3

DB_NAME = "students.db"


def get_connection():
    """Create and return a connection to the SQLite database."""
    conn = sqlite3.connect(DB_NAME)
    return conn


def create_table():
    """Create the students table if it does not already exist."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            roll_no TEXT NOT NULL UNIQUE,
            branch TEXT NOT NULL,
            year INTEGER NOT NULL,
            email TEXT
        )
    """)
    conn.commit()
    conn.close()
