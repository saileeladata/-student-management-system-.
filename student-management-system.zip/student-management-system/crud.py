"""
crud.py
Contains all the Create, Read, Update, Delete and Search
operations for the Student Management System.
"""

import sqlite3
from database import get_connection


def add_student(name, roll_no, branch, year, email):
    """Insert a new student record into the database."""
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO students (name, roll_no, branch, year, email) "
            "VALUES (?, ?, ?, ?, ?)",
            (name, roll_no, branch, year, email)
        )
        conn.commit()
        print("✅ Student added successfully.")
    except sqlite3.IntegrityError:
        print("❌ Error: A student with this roll number already exists.")
    finally:
        conn.close()


def view_students():
    """Display all student records."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM students")
    rows = cursor.fetchall()
    conn.close()
    _print_rows(rows)


def update_student(roll_no, name=None, branch=None, year=None, email=None):
    """Update an existing student's details. Blank fields keep old values."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM students WHERE roll_no = ?", (roll_no,))
    student = cursor.fetchone()

    if not student:
        print("❌ Student not found.")
        conn.close()
        return

    name = name if name else student[1]
    branch = branch if branch else student[3]
    year = year if year else student[4]
    email = email if email else student[5]

    cursor.execute(
        "UPDATE students SET name=?, branch=?, year=?, email=? WHERE roll_no=?",
        (name, branch, year, email, roll_no)
    )
    conn.commit()
    conn.close()
    print("✅ Student updated successfully.")


def delete_student(roll_no):
    """Delete a student record by roll number."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM students WHERE roll_no = ?", (roll_no,))
    student = cursor.fetchone()

    if not student:
        print("❌ Student not found.")
    else:
        cursor.execute("DELETE FROM students WHERE roll_no = ?", (roll_no,))
        conn.commit()
        print("✅ Student deleted successfully.")

    conn.close()


def search_student(keyword):
    """Search students by name or roll number (partial match)."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM students WHERE name LIKE ? OR roll_no LIKE ?",
        (f"%{keyword}%", f"%{keyword}%")
    )
    rows = cursor.fetchall()
    conn.close()
    _print_rows(rows)


def _print_rows(rows):
    """Helper function to neatly print a list of student rows."""
    if not rows:
        print("No matching students found.")
        return

    header = "{:<5} {:<20} {:<10} {:<15} {:<6} {:<25}".format(
        "ID", "Name", "Roll No", "Branch", "Year", "Email"
    )
    print("\n" + header)
    print("-" * len(header))
    for row in rows:
        print("{:<5} {:<20} {:<10} {:<15} {:<6} {:<25}".format(*row))
